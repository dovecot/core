/* Copyright (c) 2002-2018 Pigeonhole authors, see the included COPYING file
 */

#ifndef __TESTSUITE_ARGUMENTS_H
#define __TESTSUITE_ARGUMENTS_H

extern const struct sieve_argument_def testsuite_string_argument;

#endif
