/* Copyright (c) 2002-2018 Pigeonhole authors, see the included COPYING file
 */

#ifndef __LDA_SIEVE_PLUGIN_H
#define __LDA_SIEVE_PLUGIN_H

/*
 * Plugin interface
 */

void sieve_plugin_init(void);
void sieve_plugin_deinit(void);

#endif /* __LDA_SIEVE_PLUGIN_H */
