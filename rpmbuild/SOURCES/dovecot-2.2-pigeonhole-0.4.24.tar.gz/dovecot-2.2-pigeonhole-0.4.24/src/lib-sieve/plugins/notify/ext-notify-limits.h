/* Copyright (c) 2002-2018 Pigeonhole authors, see the included COPYING file
 */

#ifndef __EXT_NOTIFY_LIMITS_H
#define __EXT_NOTIFY_LIMITS_H

#define EXT_NOTIFY_MAX_RECIPIENTS  8
#define EXT_NOTIFY_MAX_MESSAGE     256

#endif /* __EXT_NOTIFY_LIMITS_H */
